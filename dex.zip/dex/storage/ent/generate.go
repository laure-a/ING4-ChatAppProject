package ent

//go:generate go run -mod=mod entgo.io/ent/cmd/ent generate ./schema --target ./db
